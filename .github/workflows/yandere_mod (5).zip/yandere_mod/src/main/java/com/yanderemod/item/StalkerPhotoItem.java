package com.yanderemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Фото, зроблене яндере крадькома. Колекційний предмет із моторошним підписом. */
public class StalkerPhotoItem extends Item {
    public StalkerPhotoItem(Properties props) {
        super(props);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.yandere_mod.stalker_photo").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
    }
}
