package com.yanderemod.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Закривавлений ніж: сильніший за звичайний, а рана «гниє» (ефект висихання, 3 секунди). */
public class BloodyKnifeItem extends SwordItem {
    public BloodyKnifeItem(Tier tier, int damage, float speed, Properties props) {
        super(tier, damage, speed, props);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (result && !attacker.level().isClientSide) {
            target.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0), attacker);
        }
        return result;
    }
}
