package com.yanderemod.registry;

import com.yanderemod.YandereMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, YandereMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.yandere_mod"))
                    .icon(() -> new ItemStack(ModItems.LOVE_LETTER.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.LOVE_LETTER.get());
                        out.accept(ModItems.YANDERE_KNIFE.get());
                        out.accept(ModItems.BREAKUP_LETTER.get());
                        out.accept(ModItems.YANDERE_DIARY.get());
                        out.accept(ModItems.HEART_CHOCOLATE.get());
                        out.accept(ModItems.RED_THREAD.get());
                        out.accept(ModItems.HANDCUFFS.get());
                        out.accept(ModItems.BENTO.get());
                        out.accept(ModItems.BLOODY_KNIFE.get());
                        out.accept(ModItems.HEART_COOKIE.get());
                        out.accept(ModItems.LOVE_POTION.get());
                        out.accept(ModItems.RED_RIBBON.get());
                        out.accept(ModItems.STALKER_PHOTO.get());
                        out.accept(ModItems.YANDERE_SPAWN_EGG.get());
                    })
                    .build());
}
