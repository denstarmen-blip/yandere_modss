package com.yanderemod.item;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/** ПКМ: показує, яка яндере зараз «пише» про тебе, її здоров'я, відстань і настрій. */
public class DiaryItem extends Item {
    public DiaryItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            List<YandereEntity> list = level.getEntitiesOfClass(YandereEntity.class,
                    player.getBoundingBox().inflate(64.0D), y -> y.isObsessedWith(player));
            if (list.isEmpty()) {
                player.sendSystemMessage(Component.translatable("message.yandere_mod.diary_empty"));
            } else {
                for (YandereEntity y : list) {
                    Component mood = Component.translatable(y.isAggressive()
                            ? "message.yandere_mod.diary_mood_angry" : "message.yandere_mod.diary_mood_calm");
                    player.sendSystemMessage(Component.translatable("message.yandere_mod.diary_entry",
                            y.getName(), String.valueOf((int) y.getHealth()),
                            String.valueOf((int) player.distanceTo(y)), mood));
                }
            }
            player.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
