package com.yanderemod;

import com.yanderemod.registry.ModEntities;
import com.yanderemod.registry.ModItems;
import com.yanderemod.registry.ModSounds;
import com.yanderemod.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(YandereMod.MODID)
public class YandereMod {
    public static final String MODID = "yandere_mod";

    public YandereMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        ModSounds.SOUNDS.register(bus);
    }
}
