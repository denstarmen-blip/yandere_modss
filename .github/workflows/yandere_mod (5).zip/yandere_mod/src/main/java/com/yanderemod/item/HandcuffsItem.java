package com.yanderemod.item;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** ПКМ по яндере: сковує її на 20 секунд (вона не може рухатися й майже не завдає шкоди). */
public class HandcuffsItem extends Item {
    public HandcuffsItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof YandereEntity yandere) {
            if (!player.level().isClientSide) {
                yandere.restrain(player);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, 60);
            }
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        return InteractionResult.PASS;
    }
}
