package com.yanderemod.registry;

import com.yanderemod.YandereMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Голос яндере. Самі звуки описані в assets/yandere_mod/sounds.json.
 * Щоб підставити свій голос — поклади .ogg у assets/yandere_mod/sounds/ і заміни записи в sounds.json.
 */
public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, YandereMod.MODID);

    public static final RegistryObject<SoundEvent> AMBIENT = reg("entity.yandere.ambient"); // буденне бурмотіння
    public static final RegistryObject<SoundEvent> LOVE = reg("entity.yandere.love");       // закохане муркотіння
    public static final RegistryObject<SoundEvent> GIGGLE = reg("entity.yandere.giggle");   // хихотіння
    public static final RegistryObject<SoundEvent> CACKLE = reg("entity.yandere.cackle");   // моторошний сміх
    public static final RegistryObject<SoundEvent> HURT = reg("entity.yandere.hurt");
    public static final RegistryObject<SoundEvent> DEATH = reg("entity.yandere.death");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(YandereMod.MODID, name)));
    }
}
