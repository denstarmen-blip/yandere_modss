package com.yanderemod.events;

import com.yanderemod.YandereMod;
import com.yanderemod.entity.YandereEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Ігрові події (Forge-шина): торгівля з жителем викликає ревнощі яндере. */
@Mod.EventBusSubscriber(modid = YandereMod.MODID)
public class ForgeEvents {
    @SubscribeEvent
    public static void onInteractVillager(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide || event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(event.getTarget() instanceof AbstractVillager villager)) return;

        for (YandereEntity y : event.getLevel().getEntitiesOfClass(YandereEntity.class,
                event.getEntity().getBoundingBox().inflate(32.0D))) {
            if (y.getObsession() == event.getEntity()) {
                y.markJealous(villager);
            }
        }
    }
}
