package com.yanderemod.client;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Модель яндере з трьома станами анімації:
 *  1) Агресія   — ніж піднятий, тремтіння рук, труська голови, погляд «вниз» на жертву.
 *  2) Закохана  — нахил голови набік, що повільно погойдується; на місці — руки зчеплені перед собою.
 *  3) Звичайна  — ванільна ходьба/дихання.
 * Удар ножем (attackTime) додається поверх піднятої руки, тому замах працює.
 */
public class YandereModel extends PlayerModel<YandereEntity> {

    public YandereModel(ModelPart root) {
        super(root, true); // true = тонкі руки (slim)
    }

    @Override
    public void setupAnim(YandereEntity e, float limbSwing, float limbSwingAmount,
                          float age, float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);

        if (e.isSleeping()) {
            // лежить у ліжку: голова рівно, руки складені біля тіла
            this.head.xRot = 0.0F; this.head.yRot = 0.0F; this.head.zRot = 0.0F;
            this.rightArm.xRot = 0.0F; this.rightArm.yRot = 0.0F; this.rightArm.zRot = 0.05F;
            this.leftArm.xRot = 0.0F; this.leftArm.yRot = 0.0F; this.leftArm.zRot = -0.05F;
            this.hat.copyFrom(this.head);
            this.leftSleeve.copyFrom(this.leftArm);
            this.rightSleeve.copyFrom(this.rightArm);
            return;
        }

        // дії над обраним (подати їжу, кинути зілля, обійняти, сфотографувати, зав'язати стрічку, помахати, ласо)
        int action = e.getAction();
        if (action != YandereEntity.A_NONE && !e.isAggressive()) {
            applyAction(e, action, e.getActionProgress(age), age);
            this.hat.copyFrom(this.head);
            this.leftSleeve.copyFrom(this.leftArm);
            this.rightSleeve.copyFrom(this.rightArm);
            return;
        }

        boolean aggressive = e.isAggressive();
        boolean obsessed = e.isObsessed();
        boolean still = limbSwingAmount < 0.05F;

        if (aggressive) {
            float tremble = Mth.sin(age * 1.9F) * 0.06F;
            float jitter = Mth.cos(age * 2.3F) * 0.04F;

            // права рука з ножем піднята (+ тремтіння); замах додається поверх
            this.rightArm.xRot += -1.15F + tremble;
            this.rightArm.zRot += 0.12F + jitter;
            // ліва рука напоготові
            this.leftArm.xRot = -0.5F + tremble;
            this.leftArm.yRot = 0.3F;
            this.leftArm.zRot = -0.1F + jitter;

            // голова: погляд спідлоба + нервове сіпання
            this.head.xRot += 0.2F;
            this.head.zRot = Mth.sin(age * 0.9F) * 0.07F;
        } else if (obsessed) {
            // голова мило нахилена набік і повільно погойдується
            this.head.zRot = 0.22F + Mth.sin(age * 0.04F) * 0.05F;

            if (still) {
                // руки зчеплені перед грудьми (з легким диханням)
                float breathe = Mth.sin(age * 0.067F) * 0.03F;
                this.rightArm.xRot = -0.95F + breathe;
                this.rightArm.yRot = -0.45F;
                this.rightArm.zRot = 0.0F;
                this.leftArm.xRot = -0.95F - breathe;
                this.leftArm.yRot = 0.45F;
                this.leftArm.zRot = 0.0F;
            }
        }

        // PlayerModel копіює частини до нашого коду — синхронізуємо верхній шар скіна
        this.hat.copyFrom(this.head);
        this.leftSleeve.copyFrom(this.leftArm);
        this.rightSleeve.copyFrom(this.rightArm);
    }

    // ---------- Анімації дій ----------

    /** Плавне входження/виходження пози: 0 → 1 → 0. */
    private static float envelope(float t) {
        float in = Mth.clamp(t / 0.2F, 0.0F, 1.0F);
        float out = Mth.clamp((1.0F - t) / 0.2F, 0.0F, 1.0F);
        float v = Math.min(in, out);
        return v * v * (3.0F - 2.0F * v);
    }

    private static float easeOut(float t) {
        t = Mth.clamp(t, 0.0F, 1.0F);
        return 1.0F - (1.0F - t) * (1.0F - t);
    }

    /** Змішує поточну (ванільну) позу частини з цільовою з вагою w. */
    private static void pose(ModelPart part, float x, float y, float z, float w) {
        part.xRot = Mth.lerp(w, part.xRot, x);
        part.yRot = Mth.lerp(w, part.yRot, y);
        part.zRot = Mth.lerp(w, part.zRot, z);
    }

    private void applyAction(YandereEntity e, int action, float t, float age) {
        float w = envelope(t);
        switch (action) {
            case YandereEntity.A_OFFER -> {
                // права рука простягає їжу, ліва — за спиною, голова мило схилена
                float push = Mth.sin(t * (float) Math.PI) * -0.18F;
                pose(this.rightArm, -1.45F + push, -0.15F, 0.0F, w);
                pose(this.leftArm, 0.45F, 0.55F, -0.12F, w);
                pose(this.head, this.head.xRot - 0.1F, this.head.yRot, 0.18F, w);
            }
            case YandereEntity.A_THROW -> {
                // замах над головою, різкий кидок уперед, повернення
                float rx;
                float rz;
                if (t < 0.5F) {
                    float wind = easeOut(t / 0.5F);
                    rx = -2.6F * wind;
                    rz = 0.3F * wind;
                } else {
                    float rel = easeOut((t - 0.5F) / 0.12F);
                    rx = -2.6F + 1.5F * rel;
                    rz = 0.3F * (1.0F - rel);
                }
                float rw = Math.min(Mth.clamp(t / 0.1F, 0.0F, 1.0F), Mth.clamp((1.0F - t) / 0.15F, 0.0F, 1.0F));
                pose(this.rightArm, rx, 0.0F, rz, rw);
                pose(this.leftArm, 0.35F, 0.0F, -0.4F, w);
                pose(this.head, this.head.xRot, this.head.yRot, 0.1F, w);
            }
            case YandereEntity.A_HUG -> {
                // обидві руки обхоплюють, легке «стискання», голова на бік
                float squeeze = t > 0.3F ? Mth.sin(age * 0.5F) * 0.05F : 0.0F;
                pose(this.rightArm, -1.25F + squeeze, -0.85F, 0.0F, w);
                pose(this.leftArm, -1.25F + squeeze, 0.85F, 0.0F, w);
                pose(this.head, 0.15F, this.head.yRot, -0.22F, w);
            }
            case YandereEntity.A_PHOTO -> {
                // «фотоапарат» перед обличчям, у момент спалаху — легка віддача
                float recoil = (t > 0.55F && t < 0.7F) ? 0.08F : 0.0F;
                pose(this.rightArm, -1.75F - recoil, -0.4F, 0.0F, w);
                pose(this.leftArm, -1.75F - recoil, 0.4F, 0.0F, w);
                pose(this.head, 0.05F - recoil, this.head.yRot, 0.0F, w);
            }
            case YandereEntity.A_TIE -> {
                // пальці «зав'язують» стрічку: дрібні рухи рук, погляд вниз
                float wiggle = Mth.sin(age * 0.9F) * 0.12F;
                pose(this.rightArm, -0.9F + wiggle, -0.5F, 0.0F, w);
                pose(this.leftArm, -0.9F - wiggle, 0.5F, 0.0F, w);
                pose(this.head, 0.35F, this.head.yRot, 0.0F, w);
            }
            case YandereEntity.A_WAVE -> {
                // рука вгору, махає з боку в бік; ліва — за спину
                float wave = Mth.sin(age * 0.8F) * 0.35F;
                pose(this.rightArm, -2.7F, 0.0F, wave, w);
                pose(this.leftArm, 0.2F, 0.3F, -0.15F, w);
                pose(this.head, this.head.xRot, this.head.yRot, 0.15F, w);
            }
            case YandereEntity.A_LASSO -> {
                // розкручує нитку над головою, потім кидає уперед
                if (t < 0.55F) {
                    float spin = age * 0.9F;
                    pose(this.rightArm, -2.7F + Mth.cos(spin) * 0.25F, Mth.sin(spin) * 0.5F,
                            Mth.cos(spin) * 0.35F, Math.min(1.0F, t / 0.12F));
                } else {
                    float rel = easeOut((t - 0.55F) / 0.1F);
                    pose(this.rightArm, -2.7F + 1.3F * rel, -0.1F * rel, 0.0F,
                            Mth.clamp((1.0F - t) / 0.2F, 0.0F, 1.0F));
                }
                pose(this.leftArm, 0.3F, 0.0F, -0.2F, w);
                pose(this.head, this.head.xRot - 0.15F, this.head.yRot, 0.0F, w);
            }
            default -> { }
        }
    }
}
