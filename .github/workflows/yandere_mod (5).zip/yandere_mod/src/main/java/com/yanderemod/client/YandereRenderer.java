package com.yanderemod.client;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * Модель гравця (slim) з анімаціями з YandereModel і власною текстурою яндере.
 * Скін: assets/yandere_mod/textures/entity/yandere.png (PNG 64x64, slim-руки).
 */
public class YandereRenderer extends MobRenderer<YandereEntity, YandereModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("yandere_mod", "textures/entity/yandere.png");

    public YandereRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new YandereModel(ctx.bakeLayer(ModelLayers.PLAYER_SLIM)), 0.5F);
        this.addLayer(new ItemInHandLayer<>(this, ctx.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(YandereEntity entity) {
        return TEXTURE;
    }
}
