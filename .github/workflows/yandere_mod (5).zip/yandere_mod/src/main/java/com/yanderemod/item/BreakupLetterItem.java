package com.yanderemod.item;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** ПКМ по яндере, яка в тебе закохана: розриває «стосунки». Вона відпускає тебе... і нападає. */
public class BreakupLetterItem extends Item {
    public BreakupLetterItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof YandereEntity yandere && yandere.isObsessedWith(player)) {
            if (!player.level().isClientSide) {
                yandere.breakUp(player);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        return InteractionResult.PASS;
    }
}
