package com.yanderemod.entity;

import com.yanderemod.registry.ModItems;
import com.yanderemod.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class YandereEntity extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OBSESSION =
            SynchedEntityData.defineId(YandereEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    /** Поточна «дія над обраним» (0 = нічого). Синхронізується з клієнтом для анімацій. */
    private static final EntityDataAccessor<Integer> ACTION =
            SynchedEntityData.defineId(YandereEntity.class, EntityDataSerializers.INT);

    private int talkCooldown;
    private int lastAggroLineTick = -1000;
    private float lastOwnerHealth = -1.0F;

    /** Жителі, на яких яндере «поклала око» (UUID -> до якого тіку гри діє ревнощі). */
    private final Map<UUID, Long> jealousUntil = new HashMap<>();
    private UUID gazeId;
    private int gazeTicks;

    /** true = лягає в сусіднє ліжко, false = стоїть біля ліжка і дивиться. Перемикання: Shift+ПКМ порожньою рукою. */
    private boolean sleepWithOwner = true;
    private boolean sleepGoalActive;
    private int lastDoorLineTick = -1000;

    public YandereEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OBSESSION, Optional.empty());
        this.entityData.define(ACTION, 0);
    }

    @Override
    protected void registerGoals() {
        // Двері: навігація може прокладати шлях крізь зачинені дерев'яні двері
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new ActionFreezeGoal(this)); // під час дії стоїть на місці
        this.goalSelector.addGoal(1, new AggroBreakDoorGoal(this)); // в агресії — ламає
        this.goalSelector.addGoal(2, new CalmOpenDoorGoal(this));   // у спокої — просто відчиняє
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(1, new SleepNearObsessionGoal(this, 1.0D));
        this.goalSelector.addGoal(2, new FollowObsessionGoal(this, 1.1D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));

        // Помста тому, хто її вдарив
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // Ревнощі: будь-який інший гравець поруч з обраним
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, target -> {
            Player owner = getObsession();
            return owner != null && target != owner && target instanceof Player p
                    && !p.isCreative() && !p.isSpectator() && p.distanceToSqr(owner) < 64.0D;
        }));
        // Захист обраного від мобів
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false, target -> {
            Player owner = getObsession();
            return owner != null && target instanceof Mob m && m != this && m.getTarget() == owner;
        }));
        // Ревнощі до жителів: торгівля з ними або довгий погляд на них
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, 10, true, false, target ->
                getObsession() != null && jealousUntil.getOrDefault(target.getUUID(), 0L) > this.level().getGameTime()));
    }

    // ---------- Дії над обраним: анімація + предмет ----------

    public static final int A_NONE = 0, A_OFFER = 1, A_THROW = 2, A_HUG = 3,
            A_PHOTO = 4, A_TIE = 5, A_WAVE = 6, A_LASSO = 7;
    /** Тривалість анімації (тіків). */
    public static final int[] ACTION_DURATION = {1, 40, 36, 50, 50, 50, 50, 44};
    /** На якому тіку анімації спрацьовує ефект. */
    private static final int[] ACTION_TRIGGER = {0, 26, 18, 25, 30, 30, 10, 24};
    /** Перезарядка дії (тіків). */
    private static final int[] ACTION_COOLDOWN = {0, 600, 1200, 2400, 3600, 6000, 600, 2400};

    private int actionLeft;
    private int actionElapsed;
    private boolean actionFired;
    private boolean offerBento;
    private final int[] actionReady = new int[8];
    private int careGlobalReady = 200;
    private boolean farSeen;
    private int clientActionStart;

    public int getAction() {
        return this.entityData.get(ACTION);
    }

    /** Прогрес поточної дії 0..1 (для моделі). ageInTicks = tickCount + partialTick. */
    public float getActionProgress(float ageInTicks) {
        int a = getAction();
        if (a == A_NONE) return 0.0F;
        return Mth.clamp((ageInTicks - this.clientActionStart) / (float) ACTION_DURATION[a], 0.0F, 1.0F);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (ACTION.equals(key)) {
            this.clientActionStart = this.tickCount;
        }
    }

    private boolean ready(int code) {
        return this.tickCount >= this.actionReady[code];
    }

    private void startAction(int code) {
        this.actionLeft = ACTION_DURATION[code];
        this.actionElapsed = 0;
        this.actionFired = false;
        this.entityData.set(ACTION, code);
        this.actionReady[code] = this.tickCount + ACTION_COOLDOWN[code];
        this.careGlobalReady = this.tickCount + 200;
        this.getNavigation().stop();

        ItemStack hold = ItemStack.EMPTY;
        switch (code) {
            case A_OFFER -> {
                this.offerBento = this.random.nextInt(3) == 0;
                hold = new ItemStack(this.offerBento ? ModItems.BENTO.get() : ModItems.HEART_COOKIE.get());
            }
            case A_THROW -> hold = new ItemStack(ModItems.LOVE_POTION.get());
            case A_TIE -> hold = new ItemStack(ModItems.RED_RIBBON.get());
            case A_LASSO -> hold = new ItemStack(ModItems.RED_THREAD.get());
            default -> { }
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, hold);
    }

    /** Завершує/скасовує дію й повертає ніж у руку. */
    private void endAction() {
        if (this.actionLeft <= 0 && this.entityData.get(ACTION) == A_NONE) return;
        this.actionLeft = 0;
        this.entityData.set(ACTION, A_NONE);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.YANDERE_KNIFE.get()));
    }

    private void serverActionTick() {
        if (this.actionLeft <= 0) {
            // після завантаження світу посеред дії в руці може лишитись не ніж
            if (this.tickCount % 40 == 0 && !this.getMainHandItem().is(ModItems.YANDERE_KNIFE.get())) {
                this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.YANDERE_KNIFE.get()));
            }
            return;
        }
        Player owner = getObsession();
        if (owner == null || !owner.isAlive()) {
            endAction();
            return;
        }
        this.getLookControl().setLookAt(owner, 30.0F, 30.0F);
        this.getNavigation().stop();
        this.actionElapsed++;
        int code = getAction();
        if (!this.actionFired && this.actionElapsed >= ACTION_TRIGGER[code]) {
            this.actionFired = true;
            fireAction(code, owner);
        }
        if (--this.actionLeft <= 0) {
            endAction();
        }
    }

    /** Вирішує, чи час зробити щось для обраного (раз на пів секунди). */
    private void serverCare() {
        if (this.actionLeft > 0 || this.tickCount % 10 != 0 || this.tickCount < this.careGlobalReady) return;
        Player owner = getObsession();
        if (owner == null || !owner.isAlive() || owner.isSpectator() || owner.isSleeping()) return;
        if (this.getTarget() != null || this.isAggressive() || this.isSleeping() || this.sleepGoalActive
                || this.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) return;

        double d2 = this.distanceToSqr(owner);
        if (d2 > 100.0D) this.farSeen = true;
        float hp = owner.getHealth();
        int code = A_NONE;

        if (hp <= 8.0F && d2 < 100.0D && ready(A_THROW)) {
            code = A_THROW;                                   // любовне зілля
        } else if (owner.getFoodData().getFoodLevel() <= 12 && d2 < 16.0D && ready(A_OFFER)) {
            code = A_OFFER;                                   // печиво / бенто
        } else if (this.farSeen && d2 < 25.0D && ready(A_WAVE)) {
            code = A_WAVE;                                    // радісно махає після розлуки
            this.farSeen = false;
        } else if (d2 > 100.0D && d2 < 576.0D && this.hasLineOfSight(owner)
                && this.random.nextInt(6) == 0 && ready(A_LASSO)) {
            code = A_LASSO;                                   // червона нитка: «не тікай»
        } else if (d2 < 9.0D && this.random.nextInt(25) == 0 && ready(A_HUG)) {
            code = A_HUG;                                     // липкі обійми
        } else if (d2 < 16.0D && this.random.nextInt(40) == 0 && ready(A_PHOTO)) {
            code = A_PHOTO;                                   // фотографує тебе
        } else if (d2 < 9.0D && !owner.hasEffect(MobEffects.DAMAGE_RESISTANCE)
                && this.random.nextInt(60) == 0 && ready(A_TIE)) {
            code = A_TIE;                                     // зав'язує червону стрічку
        }
        if (code != A_NONE) startAction(code);
    }

    private void hearts(ServerLevel sl, Entity at) {
        sl.sendParticles(ParticleTypes.HEART, at.getX(), at.getY() + 1.8D, at.getZ(), 7, 0.4D, 0.4D, 0.4D, 0.02D);
    }

    private static void trail(ServerLevel sl, Vec3 from, Vec3 to, ParticleOptions particle) {
        int steps = Math.max(4, (int) (from.distanceTo(to) * 2.0D));
        for (int i = 0; i <= steps; i++) {
            Vec3 pt = from.lerp(to, i / (double) steps);
            sl.sendParticles(particle, pt.x, pt.y, pt.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    /** Момент «ефекту» всередині анімації. */
    private void fireAction(int code, Player owner) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        double d2 = this.distanceToSqr(owner);
        switch (code) {
            case A_OFFER -> {
                if (d2 > 25.0D) return;
                owner.getFoodData().eat(this.offerBento ? 6 : 4, 0.6F);
                owner.addEffect(new MobEffectInstance(MobEffects.REGENERATION, this.offerBento ? 100 : 40, 0));
                this.playSound(SoundEvents.GENERIC_EAT, 0.8F, 1.0F);
                hearts(sl, owner);
                sayRandom(owner, "care_offer", 3);
                playVoice(ModSounds.LOVE.get());
            }
            case A_THROW -> {
                if (d2 > 144.0D) return;
                trail(sl, this.getEyePosition(), owner.getEyePosition(), ParticleTypes.WITCH);
                owner.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                owner.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 1));
                this.playSound(SoundEvents.SPLASH_POTION_BREAK, 0.8F, 1.2F);
                hearts(sl, owner);
                sayRandom(owner, "care_potion", 2);
                playVoice(ModSounds.GIGGLE.get());
            }
            case A_HUG -> {
                if (d2 > 16.0D) return;
                owner.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2)); // «не відпущу»
                owner.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0));
                this.playSound(SoundEvents.WOOL_PLACE, 1.0F, 1.0F);
                hearts(sl, owner);
                hearts(sl, this);
                sayRandom(owner, "care_hug", 2);
                playVoice(ModSounds.LOVE.get());
            }
            case A_PHOTO -> {
                Vec3 flash = this.getEyePosition().add(this.getLookAngle().scale(0.6D));
                sl.sendParticles(ParticleTypes.FLASH, flash.x, flash.y, flash.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                this.playSound(SoundEvents.TRIPWIRE_CLICK_ON, 1.0F, 1.4F);
                this.spawnAtLocation(new ItemStack(ModItems.STALKER_PHOTO.get()));
                sayRandom(owner, "care_photo", 2);
                playVoice(ModSounds.GIGGLE.get());
            }
            case A_TIE -> {
                if (d2 > 25.0D) return;
                owner.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1800, 0));
                owner.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0)); // «позначена»
                this.playSound(SoundEvents.LEASH_KNOT_PLACE, 1.0F, 1.0F);
                hearts(sl, owner);
                sayRandom(owner, "care_tie", 2);
                playVoice(ModSounds.LOVE.get());
            }
            case A_WAVE -> {
                hearts(sl, this);
                sayRandom(owner, "care_wave", 2);
                playVoice(ModSounds.GIGGLE.get());
            }
            case A_LASSO -> {
                if (d2 < 64.0D || d2 > 900.0D || !this.hasLineOfSight(owner)) return;
                if (owner.isCreative() || owner.getAbilities().flying) return;
                Vec3 dir = this.position().subtract(owner.position());
                double len = dir.length();
                Vec3 pull = dir.normalize().scale(Math.min(1.3D, 0.35D + len * 0.05D)).add(0.0D, 0.3D, 0.0D);
                owner.setDeltaMovement(pull);
                owner.hurtMarked = true;
                owner.fallDistance = 0.0F;
                owner.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                trail(sl, this.getEyePosition(), owner.getEyePosition(),
                        new DustParticleOptions(new Vector3f(0.9F, 0.05F, 0.1F), 1.2F));
                this.playSound(SoundEvents.LEASH_KNOT_PLACE, 1.0F, 0.7F);
                sayRandom(owner, "care_lasso", 3);
                playVoice(ModSounds.CACKLE.get());
            }
            default -> { }
        }
    }

    // ---------- Одержимість ----------

    @Nullable
    public Player getObsession() {
        UUID id = this.entityData.get(OBSESSION).orElse(null);
        return id == null ? null : this.level().getPlayerByUUID(id);
    }

    public boolean isObsessed() {
        return this.entityData.get(OBSESSION).isPresent();
    }

    public void setObsession(@Nullable Player player) {
        this.entityData.set(OBSESSION, Optional.ofNullable(player == null ? null : player.getUUID()));
        if (player != null) {
            this.setPersistenceRequired();
            this.setTarget(null);
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8D, getZ(), 8, 0.4D, 0.4D, 0.4D, 0.02D);
            }
            say(player, "message.yandere_mod.love");
            playVoice(ModSounds.GIGGLE.get());
        }
    }

    // ---------- Публічні дії для предметів ----------

    /** Шоколад: яндере заспокоюється, лікується і мило радіє. */
    public void receiveGift(Player player) {
        this.heal(6.0F);
        this.setTarget(null);
        this.setAggressive(false);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8D, getZ(), 6, 0.4D, 0.4D, 0.4D, 0.02D);
        }
        sayRandom(player, "gift_choc", 2);
        playVoice(ModSounds.GIGGLE.get());
    }

    /** Лист про розрив: вона «відпускає» коханого... і біжить мститися. */
    public void breakUp(Player player) {
        this.entityData.set(OBSESSION, Optional.empty());
        say(player, "message.yandere_mod.breakup" + (1 + this.random.nextInt(3)));
        playVoice(ModSounds.CACKLE.get());
        this.lastAggroLineTick = this.tickCount; // щоб не дублювати репліку «помсти»
        this.setTarget(player);
    }

    /** Червона нитка: яндере миттєво телепортується до гравця. */
    public void recallTo(Player player) {
        if (this.isSleeping()) this.stopSleeping();
        this.getNavigation().stop();
        this.moveTo(player.getX(), player.getY(), player.getZ(), this.getYRot(), this.getXRot());
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8D, getZ(), 8, 0.4D, 0.4D, 0.4D, 0.02D);
        }
        sayRandom(player, "thread", 2);
        playVoice(ModSounds.GIGGLE.get());
    }

    /** Кайданки: 20 секунд не може рухатися та майже не б'є. */
    public void restrain(Player player) {
        endAction();
        if (this.isSleeping()) this.stopSleeping();
        this.setTarget(null);
        this.setAggressive(false);
        this.getNavigation().stop();
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 9));
        this.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 400, 3));
        sayRandom(player, "restrained", 3);
        playVoice(ModSounds.AMBIENT.get());
    }

    public boolean isObsessedWith(Player player) {
        return this.entityData.get(OBSESSION).map(id -> id.equals(player.getUUID())).orElse(false);
    }

    private void say(Player player, String key) {
        player.sendSystemMessage(Component.translatable("message.yandere_mod.format",
                this.getName(), Component.translatable(key)));
    }

    /** Випадкова репліка з набору prefix1..prefixN (напр. "hurt_owner", 3). */
    private void sayRandom(Player player, String prefix, int count) {
        say(player, "message.yandere_mod." + prefix + (1 + this.random.nextInt(count)));
        this.talkCooldown = 100; // не частіше ніж раз на 5 секунд
    }

    private void playVoice(SoundEvent sound) {
        this.playSound(sound, 1.0F, 1.0F + (this.random.nextFloat() - 0.5F) * 0.1F);
    }

    /** Позначає жителя як «суперника»: яндере нападе на нього найближчі 2 хвилини. */
    public void markJealous(AbstractVillager villager) {
        Player owner = getObsession();
        if (owner == null || this.level().isClientSide) return;
        long now = this.level().getGameTime();
        boolean alreadyJealous = jealousUntil.getOrDefault(villager.getUUID(), 0L) > now;
        jealousUntil.put(villager.getUUID(), now + 2400L);
        if (!alreadyJealous) {
            say(owner, "message.yandere_mod.villager_jealous" + (1 + this.random.nextInt(3)));
            playVoice(ModSounds.CACKLE.get());
        }
    }

    /** Стежимо, чи довго власник дивиться на жителя (≈3 секунди). */
    private void checkGaze(Player owner) {
        Vec3 eye = owner.getEyePosition();
        Vec3 look = owner.getLookAngle();
        AbstractVillager best = null;
        double bestDot = 0.985D;
        for (AbstractVillager v : this.level().getEntitiesOfClass(AbstractVillager.class, owner.getBoundingBox().inflate(8.0D))) {
            Vec3 to = v.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist < 0.5D) continue;
            double dot = look.dot(to.scale(1.0D / dist));
            if (dot > bestDot && owner.hasLineOfSight(v)) {
                best = v;
                bestDot = dot;
            }
        }
        if (best == null) {
            gazeId = null;
            gazeTicks = 0;
            return;
        }
        if (!best.getUUID().equals(gazeId)) {
            gazeId = best.getUUID();
            gazeTicks = 0;
        }
        gazeTicks += 5;
        if (gazeTicks >= 60) {
            markJealous(best);
            gazeTicks = 0;
        }
    }

    /** Усі «живі» репліки яндере залежно від ситуації. Викликається лише на сервері. */
    private void serverTalk() {
        if (this.talkCooldown > 0) this.talkCooldown--;
        if (this.isSleeping() && !this.sleepGoalActive && this.tickCount > 40) {
            this.stopSleeping();
        }
        Player owner = getObsession();

        if (owner != null) {
            // коханого вдарили — реагуємо миттєво
            float hp = owner.getHealth();
            if (this.lastOwnerHealth >= 0.0F && hp < this.lastOwnerHealth - 0.9F && owner.isAlive()) {
                sayRandom(owner, "hurt_owner", 3);
                playVoice(ModSounds.CACKLE.get());
            }
            this.lastOwnerHealth = hp;

            if (this.tickCount % 5 == 0 && !owner.isSleeping()) checkGaze(owner);
            if (this.tickCount % 20 != 0) return;

            if (this.talkCooldown <= 0 && this.getTarget() == null) {
                if (owner.isSleeping()) {
                    // репліки під час сну керує SleepNearObsessionGoal
                } else if (hp <= 8.0F && owner.isAlive() && this.random.nextInt(6) == 0) {
                    sayRandom(owner, "low_hp", 2);
                    playVoice(ModSounds.AMBIENT.get());
                } else if (this.distanceToSqr(owner) > 144.0D && this.random.nextInt(5) == 0) {
                    sayRandom(owner, "far", 2);
                    playVoice(ModSounds.AMBIENT.get());
                } else if (!this.level().isDay() && this.random.nextInt(50) == 0) {
                    sayRandom(owner, "night", 2);
                    playVoice(ModSounds.LOVE.get());
                } else if (this.random.nextInt(70) == 0) {
                    sayRandom(owner, "line", 10);
                    playVoice(this.random.nextBoolean() ? ModSounds.GIGGLE.get() : ModSounds.LOVE.get());
                }
            }
            if (this.random.nextInt(300) == 0) {
                this.spawnAtLocation(Items.POPPY); // «подарунок»
                say(owner, "message.yandere_mod.gift");
                playVoice(ModSounds.GIGGLE.get());
            }
        } else if (this.tickCount % 40 == 0 && this.talkCooldown <= 0 && this.getTarget() == null) {
            // самотня яндере підказує, що їй потрібен любовний лист
            Player near = this.level().getNearestPlayer(this, 6.0D);
            if (near != null && !near.isSpectator() && this.random.nextInt(8) == 0) {
                sayRandom(near, "lonely", 4);
                playVoice(ModSounds.AMBIENT.get());
            }
        }
    }

    /** Нова ціль-гравець: ревнощі (якщо є кохана людина) або помста. */
    @Override
    public void setTarget(@Nullable LivingEntity target) {
        boolean hadTarget = this.getTarget() != null;
        super.setTarget(target);
        if (target != null && !this.level().isClientSide) endAction();
        if (target != null && this.isSleeping() && !this.level().isClientSide) {
            this.stopSleeping();
        }
        if (!this.level().isClientSide && !hadTarget && target instanceof Player p
                && this.tickCount - this.lastAggroLineTick > 100) {
            this.lastAggroLineTick = this.tickCount;
            Player owner = getObsession();
            if (owner != null && owner != p) {
                say(p, "message.yandere_mod.jealous" + (1 + this.random.nextInt(3)));
                say(owner, "message.yandere_mod.protect" + (1 + this.random.nextInt(2)));
            } else {
                say(p, "message.yandere_mod.revenge" + (1 + this.random.nextInt(3)));
            }
            playVoice(ModSounds.CACKLE.get());
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean result = super.doHurtTarget(target);
        Player owner = getObsession();
        if (result && owner != null && target instanceof AbstractVillager && !target.isAlive()) {
            jealousUntil.remove(target.getUUID());
            sayRandom(owner, "villager_killed", 2);
            playVoice(ModSounds.GIGGLE.get());
        }
        if (result && owner != null && target instanceof Player victim && victim != owner
                && !victim.isAlive()) {
            sayRandom(owner, "killed", 2);
            playVoice(ModSounds.CACKLE.get());
        }
        return result;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide) {
            endAction();
            Player owner = getObsession();
            if (owner != null) {
                say(owner, "message.yandere_mod.death" + (1 + this.random.nextInt(2)));
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            // Візуальні ефекти під стан: сердечка (закохана) / злість (агресія)
            if (this.isAggressive()) {
                if (this.random.nextInt(15) == 0) {
                    this.level().addParticle(ParticleTypes.ANGRY_VILLAGER,
                            this.getRandomX(0.5D), this.getY() + 2.0D, this.getRandomZ(0.5D), 0.0D, 0.0D, 0.0D);
                }
            } else if (this.isObsessed() && this.random.nextInt(25) == 0) {
                this.level().addParticle(ParticleTypes.HEART,
                        this.getRandomX(0.6D), this.getY() + 1.9D, this.getRandomZ(0.6D), 0.0D, 0.04D, 0.0D);
            }
        }
        if (!this.level().isClientSide) {
            serverTalk();
            serverActionTick();
            serverCare();
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && source.getEntity() instanceof Player p) {
            UUID id = this.entityData.get(OBSESSION).orElse(null);
            if (p.getUUID().equals(id)) {
                this.entityData.set(OBSESSION, Optional.empty());
                say(p, "message.yandere_mod.betrayed");
                playVoice(ModSounds.CACKLE.get());
            }
        }
        if (!this.level().isClientSide && this.isSleeping()) {
            this.stopSleeping();
        }
        if (!this.level().isClientSide) endAction();
        return super.hurt(source, amount);
    }

    // ---------- Режим сну: Shift+ПКМ порожньою рукою ----------

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand == InteractionHand.MAIN_HAND && player.isShiftKeyDown()
                && player.getItemInHand(hand).isEmpty() && this.isObsessed()
                && player.getUUID().equals(this.entityData.get(OBSESSION).orElse(null))) {
            if (!this.level().isClientSide) {
                this.sleepWithOwner = !this.sleepWithOwner;
                say(player, this.sleepWithOwner ? "message.yandere_mod.mode_sleep" : "message.yandere_mod.mode_watch");
                playVoice(ModSounds.GIGGLE.get());
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ---------- Спавн, звуки, NBT ----------

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.YANDERE_KNIFE.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setLeftHanded(false); // анімації моделі розраховані на ніж у правій руці
        return result;
    }

    @Override
    @Nullable
    protected SoundEvent getAmbientSound() {
        if (this.isAggressive()) return null;
        return this.isObsessed() ? ModSounds.LOVE.get() : ModSounds.AMBIENT.get();
    }

    @Override
    public int getAmbientSoundInterval() {
        return 200; // рідше, щоб не набридало
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEATH.get();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        this.entityData.get(OBSESSION).ifPresent(id -> tag.putUUID("Obsession", id));
        tag.putBoolean("SleepWithOwner", this.sleepWithOwner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SleepWithOwner")) {
            this.sleepWithOwner = tag.getBoolean("SleepWithOwner");
        }
        if (tag.hasUUID("Obsession")) {
            this.entityData.set(OBSESSION, Optional.of(tag.getUUID("Obsession")));
        }
    }

    // ---------- Ціль: ходити за обраним ----------

    static class FollowObsessionGoal extends Goal {
        private final YandereEntity mob;
        private final double speed;
        private Player owner;
        private int recalc;

        FollowObsessionGoal(YandereEntity mob, double speed) {
            this.mob = mob;
            this.speed = speed;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            this.owner = mob.getObsession();
            return owner != null && owner.isAlive() && !owner.isSpectator()
                    && mob.getTarget() == null && mob.distanceToSqr(owner) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && mob.getTarget() == null
                    && mob.distanceToSqr(owner) > 4.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            mob.getLookControl().setLookAt(owner, 10.0F, (float) mob.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (mob.distanceToSqr(owner) > 400.0D) { // далі 20 блоків — «телепорт до коханого»
                    mob.moveTo(owner.getX() + 1.5D, owner.getY(), owner.getZ() + 1.5D, mob.getYRot(), mob.getXRot());
                    mob.getNavigation().stop();
                } else {
                    mob.getNavigation().moveTo(owner, speed);
                }
            }
        }
    }

    // ---------- Ціль: спати поруч / спостерігати, поки обраний спить ----------

    static class SleepNearObsessionGoal extends Goal {
        private static final int WALK_TO_BED = 0, LYING = 1, WALK_TO_SPOT = 2, WATCHING = 3;

        private final YandereEntity mob;
        private final double speed;
        private Player owner;
        private BlockPos bedPos;
        private BlockPos watchPos;
        private int phase;
        private int timer;
        private boolean reachedAnything;

        SleepNearObsessionGoal(YandereEntity mob, double speed) {
            this.mob = mob;
            this.speed = speed;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player p = mob.getObsession();
            return p != null && p.isAlive() && p.isSleeping() && mob.getTarget() == null
                    && !mob.isSleeping() && mob.distanceToSqr(p) < 576.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner == mob.getObsession() && owner.isAlive()
                    && owner.isSleeping() && mob.getTarget() == null;
        }

        @Override
        public void start() {
            this.owner = mob.getObsession();
            this.timer = 0;
            this.reachedAnything = false;
            mob.sleepGoalActive = true;
            BlockPos ownerBed = owner.getSleepingPos().orElse(owner.blockPosition());
            this.bedPos = mob.sleepWithOwner ? findFreeBed(ownerBed) : null;
            if (bedPos != null) {
                phase = WALK_TO_BED;
            } else {
                phase = WALK_TO_SPOT;
                this.watchPos = findWatchSpot(ownerBed);
                if (mob.sleepWithOwner) {
                    mob.say(owner, "message.yandere_mod.sleep_nobed1");
                }
            }
        }

        @Override
        public void stop() {
            if (mob.isSleeping()) mob.stopSleeping();
            mob.sleepGoalActive = false;
            mob.getNavigation().stop();
            if (owner != null && owner.isAlive() && !owner.isSleeping()
                    && owner == mob.getObsession() && reachedAnything) {
                mob.sayRandom(owner, "morning", 4);
                mob.playVoice(ModSounds.GIGGLE.get());
            }
            owner = null;
            bedPos = null;
            watchPos = null;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            timer++;
            if (phase == WALK_TO_BED) {
                double cx = bedPos.getX() + 0.5D, cy = bedPos.getY(), cz = bedPos.getZ() + 0.5D;
                if (timer % 10 == 1) mob.getNavigation().moveTo(cx, cy, cz, speed);
                mob.getLookControl().setLookAt(cx, cy + 0.5D, cz);
                if (mob.distanceToSqr(cx, cy, cz) < 2.25D && Math.abs(mob.getY() - cy) < 1.5D) {
                    BlockState st = mob.level().getBlockState(bedPos);
                    if (st.getBlock() instanceof BedBlock && !st.getValue(BedBlock.OCCUPIED)) {
                        mob.getNavigation().stop();
                        mob.startSleeping(bedPos);
                        phase = LYING;
                        reachedAnything = true;
                        mob.say(owner, "message.yandere_mod.sleep_with" + (1 + mob.random.nextInt(2)));
                        mob.playVoice(ModSounds.LOVE.get());
                    } else {
                        fallbackToWatching();
                    }
                } else if (timer > 400) {
                    fallbackToWatching();
                }
            } else if (phase == LYING) {
                if (!mob.isSleeping()) {
                    fallbackToWatching(); // розбудили — тоді просто дивимось
                }
            } else if (phase == WALK_TO_SPOT) {
                double tx = watchPos != null ? watchPos.getX() + 0.5D : owner.getX();
                double ty = watchPos != null ? watchPos.getY() : owner.getY();
                double tz = watchPos != null ? watchPos.getZ() + 0.5D : owner.getZ();
                if (timer % 10 == 1) mob.getNavigation().moveTo(tx, ty, tz, speed);
                mob.getLookControl().setLookAt(owner.getX(), owner.getEyeY(), owner.getZ());
                if (mob.distanceToSqr(tx, ty, tz) < 1.5D || timer > 300 || mob.distanceToSqr(owner) < 4.0D) {
                    mob.getNavigation().stop();
                    phase = WATCHING;
                    timer = 0;
                    reachedAnything = true;
                    mob.say(owner, "message.yandere_mod.watch_start" + (1 + mob.random.nextInt(2)));
                    mob.playVoice(ModSounds.AMBIENT.get());
                }
            } else { // WATCHING
                mob.getLookControl().setLookAt(owner.getX(), owner.getEyeY(), owner.getZ());
                if (timer % 300 == 0) {
                    mob.sayRandom(owner, "watch", 4);
                    mob.playVoice(this.mob.random.nextBoolean() ? ModSounds.AMBIENT.get() : ModSounds.LOVE.get());
                }
            }
        }

        private void fallbackToWatching() {
            if (mob.isSleeping()) mob.stopSleeping();
            BlockPos ownerBed = owner.getSleepingPos().orElse(owner.blockPosition());
            this.watchPos = findWatchSpot(ownerBed);
            this.phase = WALK_TO_SPOT;
            this.timer = 0;
        }

        /** Найближче вільне ліжко (інше, ніж у обраного) в радіусі 6 блоків від його ліжка. Повертає голову ліжка. */
        @Nullable
        private BlockPos findFreeBed(BlockPos ownerBed) {
            Level level = mob.level();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (int dx = -6; dx <= 6; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dz = -6; dz <= 6; dz++) {
                        BlockPos p = ownerBed.offset(dx, dy, dz);
                        BlockState bs = level.getBlockState(p);
                        if (!(bs.getBlock() instanceof BedBlock)) continue;
                        BlockPos head = bs.getValue(BedBlock.PART) == BedPart.HEAD
                                ? p : p.relative(bs.getValue(BedBlock.FACING));
                        BlockState hs = level.getBlockState(head);
                        if (!(hs.getBlock() instanceof BedBlock)
                                || hs.getValue(BedBlock.PART) != BedPart.HEAD
                                || hs.getValue(BedBlock.OCCUPIED)) continue;
                        double d = head.distSqr(ownerBed);
                        if (d < bestDist) {
                            bestDist = d;
                            best = head;
                        }
                    }
                }
            }
            return best;
        }

        /** Місце, де можна стояти поруч з ліжком обраного. */
        @Nullable
        private BlockPos findWatchSpot(BlockPos ownerBed) {
            Level level = mob.level();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        BlockPos p = ownerBed.offset(dx, dy, dz);
                        BlockPos below = p.below();
                        if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) continue;
                        if (!level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()) continue;
                        if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) continue;
                        double d = p.distSqr(ownerBed) + 0.1D * mob.distanceToSqr(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D);
                        if (d < bestDist) {
                            bestDist = d;
                            best = p;
                        }
                    }
                }
            }
            return best;
        }
    }

    // ---------- Двері: у агресії ламає, у спокої відчиняє ----------

    /** Ламає дерев'яні двері лише в стані агресії (поважає правило mobGriefing). Залізні двері їй не під силу. */
    static class AggroBreakDoorGoal extends BreakDoorGoal {
        private final YandereEntity yandere;

        AggroBreakDoorGoal(YandereEntity yandere) {
            super(yandere, d -> d != Difficulty.PEACEFUL);
            this.yandere = yandere;
        }

        @Override
        public boolean canUse() {
            return yandere.isAggressive() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return yandere.isAggressive() && super.canContinueToUse();
        }

        @Override
        protected int getDoorBreakTime() {
            return 100; // 5 секунд (у зомбі — 12)
        }

        @Override
        public void start() {
            super.start();
            if (yandere.getTarget() instanceof Player p && yandere.tickCount - yandere.lastDoorLineTick > 200) {
                yandere.lastDoorLineTick = yandere.tickCount;
                yandere.say(p, "message.yandere_mod.door" + (1 + yandere.random.nextInt(3)));
                yandere.playVoice(ModSounds.CACKLE.get());
            }
        }
    }

    /** Звичайне відчинення дверей, коли вона не агресивна. */
    static class CalmOpenDoorGoal extends OpenDoorGoal {
        private final YandereEntity yandere;

        CalmOpenDoorGoal(YandereEntity yandere) {
            super(yandere, true);
            this.yandere = yandere;
        }

        @Override
        public boolean canUse() {
            return !yandere.isAggressive() && super.canUse();
        }
    }

    // ---------- Під час дії яндере стоїть і дивиться на обраного ----------

    static class ActionFreezeGoal extends Goal {
        private final YandereEntity mob;

        ActionFreezeGoal(YandereEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return mob.actionLeft > 0;
        }

        @Override
        public boolean canContinueToUse() {
            return mob.actionLeft > 0;
        }

        @Override
        public void tick() {
            mob.getNavigation().stop();
        }
    }
}
