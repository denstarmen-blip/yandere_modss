package com.yanderemod.item;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.Comparator;
import java.util.List;

/** ПКМ: «потягнути за нитку» — найближча закохана в тебе яндере (до 128 блоків) телепортується до тебе. */
public class RedThreadItem extends Item {
    public RedThreadItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            List<YandereEntity> list = level.getEntitiesOfClass(YandereEntity.class,
                    player.getBoundingBox().inflate(128.0D), y -> y.isObsessedWith(player));
            if (list.isEmpty()) {
                player.sendSystemMessage(Component.translatable("message.yandere_mod.thread_none"));
            } else {
                YandereEntity nearest = list.stream()
                        .min(Comparator.comparingDouble(y -> y.distanceToSqr(player))).get();
                nearest.recallTo(player);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, 100);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
