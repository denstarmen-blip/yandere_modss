package com.yanderemod.registry;

import com.yanderemod.YandereMod;
import com.yanderemod.item.BloodyKnifeItem;
import com.yanderemod.item.BreakupLetterItem;
import com.yanderemod.item.DiaryItem;
import com.yanderemod.item.HandcuffsItem;
import com.yanderemod.item.HeartChocolateItem;
import com.yanderemod.item.LoveLetterItem;
import com.yanderemod.item.LovePotionItem;
import com.yanderemod.item.RedRibbonItem;
import com.yanderemod.item.StalkerPhotoItem;
import com.yanderemod.item.RedThreadItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, YandereMod.MODID);

    public static final RegistryObject<Item> LOVE_LETTER = ITEMS.register("love_letter",
            () -> new LoveLetterItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> YANDERE_KNIFE = ITEMS.register("yandere_knife",
            () -> new SwordItem(Tiers.IRON, 2, -1.6F, new Item.Properties()));

    public static final RegistryObject<Item> BREAKUP_LETTER = ITEMS.register("breakup_letter",
            () -> new BreakupLetterItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> YANDERE_DIARY = ITEMS.register("yandere_diary",
            () -> new DiaryItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> HEART_CHOCOLATE = ITEMS.register("heart_chocolate",
            () -> new HeartChocolateItem(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(4).saturationMod(0.6F).build())));

    public static final RegistryObject<Item> RED_THREAD = ITEMS.register("red_thread",
            () -> new RedThreadItem(new Item.Properties().durability(8)));

    public static final RegistryObject<Item> HANDCUFFS = ITEMS.register("handcuffs",
            () -> new HandcuffsItem(new Item.Properties().durability(6)));

    public static final RegistryObject<Item> BENTO = ITEMS.register("bento",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(9).saturationMod(0.8F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F).build())));

    public static final RegistryObject<Item> BLOODY_KNIFE = ITEMS.register("bloody_knife",
            () -> new BloodyKnifeItem(Tiers.IRON, 3, -1.6F, new Item.Properties()));

    public static final RegistryObject<Item> HEART_COOKIE = ITEMS.register("heart_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationMod(0.4F).fast().build())));

    public static final RegistryObject<Item> LOVE_POTION = ITEMS.register("love_potion",
            () -> new LovePotionItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> RED_RIBBON = ITEMS.register("red_ribbon",
            () -> new RedRibbonItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> STALKER_PHOTO = ITEMS.register("stalker_photo",
            () -> new StalkerPhotoItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> YANDERE_SPAWN_EGG = ITEMS.register("yandere_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.YANDERE, 0xF48FB1, 0x8B0000, new Item.Properties()));
}
